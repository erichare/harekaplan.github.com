Election-2012
=============

Analysis of the 2012 US Presidential Election