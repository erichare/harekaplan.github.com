require(devtools)

install_github("slidify", "ramnathv")
install_github("slidifyLibraries", "ramnathv")

library(slidify)